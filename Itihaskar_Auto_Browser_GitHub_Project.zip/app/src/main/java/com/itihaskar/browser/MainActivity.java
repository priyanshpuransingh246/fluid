package com.itihaskar.browser;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_RESULT_CODE = 1001;
    private static final int FOLDER_PICKER_RESULT_CODE = 1002;
    private static final int NEW_PDF_PICKER_RESULT_CODE = 1003;

    private static final String HOME_ASSET_URL = "file:///android_asset/studio.html";
    private static final String CHATGPT_URL = "https://chatgpt.com/";
    private static final String FLOW_URL = "https://labs.google/fx/tools/flow";

    private static final String[] CHATGPT_ONLY_DOMAINS = new String[]{
            "https://chatgpt.com/",
            "https://.chatgpt.com/",
            "https://auth.openai.com/",
            "https://auth0.openai.com/",
            "https://openai.com/",
            "https://.openai.com/"
    };

    private static final String[] CHATGPT_AUTH_DOMAINS = new String[]{
            "https://chatgpt.com/",
            "https://auth.openai.com/",
            "https://auth0.openai.com/",
            "https://openai.com/",
            "https://accounts.google.com/"
    };

    private static final String[] FLOW_ONLY_DOMAINS = new String[]{
            "https://labs.google/",
            "https://flow.google.com/"
    };

    private static final String[] FLOW_AUTH_DOMAINS = new String[]{
            "https://labs.google/",
            "https://flow.google.com/",
            "https://accounts.google.com/",
            "https://google.com/"
    };

    private LinearLayout topBarContainer;
    private TextView tabHomeBtn;
    private TextView tabChatGptBtn;
    private TextView tabFlowBtn;

    private FrameLayout contentArea;
    private WebView homeWebView;
    private WebView chatgptWebView;
    private WebView flowWebView;
    private boolean chatgptInitialLoaded = false;
    private boolean flowInitialLoaded = false;
    private String activeTabName = "home";

    private SharedPreferences prefs;
    private ValueCallback<Uri[]> fileUploadCallback;
    private String cachedAutoBotJs = "";
    private String cleanChromeUa = "";
    private int activeDownloadSceneNo = 0;
    private int pendingAutoUploadSceneNo = 0;
    private int currentChatGptAccountIndex = 1;
    private int currentFlowAccountIndex = 1;
    private int currentlyLoadedChatGptAcc = 0;
    private int currentlyLoadedFlowAcc = 0;
    private final ExecutorService bgExecutor = Executors.newSingleThreadExecutor();

    private int dp(float val) {
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, val, getResources().getDisplayMetrics());
    }

    private GradientDrawable makeTabDrawable(String fillHex, String strokeHex, float radiusDp, int strokeWidthDp) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.parseColor(fillHex));
        gd.setCornerRadius(dp(radiusDp));
        if (strokeHex != null && !strokeHex.isEmpty() && strokeWidthDp > 0) {
            gd.setStroke(Math.max(1, dp(strokeWidthDp)), Color.parseColor(strokeHex));
        }
        return gd;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        prefs = getSharedPreferences("FluidStudio_v11", MODE_PRIVATE);
        currentChatGptAccountIndex = prefs.getInt("ACTIVE_CHATGPT_ACC_IDX", 1);
        currentFlowAccountIndex = prefs.getInt("ACTIVE_FLOW_ACC_IDX", 1);
        currentlyLoadedChatGptAcc = prefs.getInt("LOADED_CHATGPT_ACC_NOW", 0);
        currentlyLoadedFlowAcc = prefs.getInt("LOADED_FLOW_ACC_NOW", 0);

        loadAutoBotAssetIntoRam();

        LinearLayout rootVertical = new LinearLayout(this);
        rootVertical.setOrientation(LinearLayout.VERTICAL);
        rootVertical.setBackgroundColor(Color.parseColor("#0B0F17"));

        topBarContainer = new LinearLayout(this);
        topBarContainer.setOrientation(LinearLayout.VERTICAL);
        topBarContainer.setBackgroundColor(Color.parseColor("#0B0F17"));
        topBarContainer.setVisibility(View.GONE);

        LinearLayout tabRow = new LinearLayout(this);
        tabRow.setOrientation(LinearLayout.HORIZONTAL);
        tabRow.setGravity(Gravity.CENTER_VERTICAL);
        tabRow.setPadding(dp(10), dp(7), dp(10), dp(7));

        tabHomeBtn = createTopTabButton("Home", v -> switchVisibleTab("home"));
        tabChatGptBtn = createTopTabButton("Chatgpt", v -> {
            ensureChatGptLoaded();
            switchVisibleTab("chatgpt");
        });
        tabFlowBtn = createTopTabButton("Flow ai", v -> {
            ensureFlowLoaded();
            switchVisibleTab("flow");
        });

        tabRow.addView(tabHomeBtn, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f));
        tabRow.addView(tabChatGptBtn, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f));
        tabRow.addView(tabFlowBtn, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f));

        topBarContainer.addView(tabRow, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        View borderLine = new View(this);
        borderLine.setBackgroundColor(Color.parseColor("#1E293B"));
        topBarContainer.addView(borderLine, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                Math.max(1, dp(1))
        ));

        rootVertical.addView(topBarContainer, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        contentArea = new FrameLayout(this);
        contentArea.setBackgroundColor(Color.parseColor("#0B0F17"));

        flowWebView = createConfiguredWebView(false, 2);
        chatgptWebView = createConfiguredWebView(false, 1);
        homeWebView = createConfiguredWebView(true, 0);

        contentArea.addView(flowWebView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));
        contentArea.addView(chatgptWebView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));
        contentArea.addView(homeWebView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));

        rootVertical.addView(contentArea, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1.0f
        ));

        setContentView(rootVertical);

        boolean folderDone = prefs.getBoolean("FOLDER_SETUP_DONE", false);
        if (!folderDone) {
            topBarContainer.setVisibility(View.GONE);
            homeWebView.loadUrl(HOME_ASSET_URL + "?mode=landing");
        } else {
            ensureSubfoldersExist();
            homeWebView.loadUrl(HOME_ASSET_URL + "?mode=home");
        }

        switchVisibleTab("home");
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            CookieManager.getInstance().flush();
        } catch (Exception ignored) {}
    }

    private void ensureChatGptLoaded() {
        if (!chatgptInitialLoaded) {
            chatgptInitialLoaded = true;
            int totalSaved = getSavedAccountCountInternal(1);
            if (totalSaved > 0 && currentlyLoadedChatGptAcc == 0) {
                loadAccountCookiesIntoWebView(1, currentChatGptAccountIndex, false, () -> chatgptWebView.loadUrl(CHATGPT_URL));
            } else {
                chatgptWebView.loadUrl(CHATGPT_URL);
            }
        }
    }

    private void ensureFlowLoaded() {
        if (!flowInitialLoaded) {
            flowInitialLoaded = true;
            int totalSaved = getSavedAccountCountInternal(2);
            if (totalSaved > 0 && currentlyLoadedFlowAcc == 0) {
                loadAccountCookiesIntoWebView(2, currentFlowAccountIndex, false, () -> flowWebView.loadUrl(FLOW_URL));
            } else {
                flowWebView.loadUrl(FLOW_URL);
            }
        }
    }

    private TextView createTopTabButton(String title, View.OnClickListener listener) {
        TextView tv = new TextView(this);
        tv.setText(title);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setGravity(Gravity.CENTER);
        tv.setSingleLine(true);
        tv.setPadding(dp(10), dp(8), dp(10), dp(8));
        tv.setOnClickListener(listener);
        return tv;
    }

    private void updateTopTabStyles() {
        styleSingleTab(tabHomeBtn, "home".equals(activeTabName));
        styleSingleTab(tabChatGptBtn, "chatgpt".equals(activeTabName));
        styleSingleTab(tabFlowBtn, "flow".equals(activeTabName));
    }

    private void styleSingleTab(TextView tab, boolean isActive) {
        if (tab == null) return;
        LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) tab.getLayoutParams();
        if (lp != null) {
            lp.setMargins(dp(4), 0, dp(4), 0);
            tab.setLayoutParams(lp);
        }
        if (isActive) {
            tab.setBackground(makeTabDrawable("#FF5500", "#FF8A1F", 10f, 1));
            tab.setTextColor(Color.parseColor("#180600"));
        } else {
            tab.setBackground(makeTabDrawable("#161B26", "#334155", 10f, 1));
            tab.setTextColor(Color.parseColor("#E2E8F0"));
        }
    }

    private void switchVisibleTab(String tabName) {
        activeTabName = tabName;
        updateTopTabStyles();
        if ("chatgpt".equals(tabName)) {
            ensureChatGptLoaded();
            chatgptWebView.bringToFront();
        } else if ("flow".equals(tabName)) {
            ensureFlowLoaded();
            flowWebView.bringToFront();
        } else {
            homeWebView.bringToFront();
        }
        contentArea.requestLayout();
        contentArea.invalidate();
    }

    private WebView createConfiguredWebView(final boolean isHomeWebView, final int botTypeForWv) {
        WebView wv = new WebView(this);
        wv.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        wv.setBackgroundColor(Color.parseColor("#0B0F17"));

        WebSettings ws = wv.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);
        ws.setAllowFileAccessFromFileURLs(true);
        ws.setAllowUniversalAccessFromFileURLs(true);
        ws.setJavaScriptCanOpenWindowsAutomatically(true);
        ws.setSupportMultipleWindows(false);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setCacheMode(WebSettings.LOAD_DEFAULT);
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);

        String defaultUa = ws.getUserAgentString();
        cleanChromeUa = defaultUa
                .replace("; wv", "")
                .replace("Version/4.0 ", "");
        ws.setUserAgentString(cleanChromeUa);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(wv, true);

        wv.addJavascriptInterface(new AndroidBotBridge(), "AndroidBotBridge");

        wv.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                String stealthJs = "try { Object.defineProperty(navigator, 'webdriver', {get: () => false}); } catch(e) {}";
                view.evaluateJavascript(stealthJs, null);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String reqUrl = request.getUrl().toString();
                if (reqUrl.contains("accounts.google.com")) {
                    Map<String, String> headers = new HashMap<>();
                    headers.put("X-Requested-With", "");
                    view.loadUrl(reqUrl, headers);
                    return true;
                }
                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                bgExecutor.execute(() -> {
                    try { CookieManager.getInstance().flush(); } catch (Exception ignored) {}
                });
                if (!isHomeWebView && url != null
                        && !url.contains("accounts.google.com")
                        && !url.contains("auth.openai.com")
                        && !url.contains("auth0.openai.com")
                        && !url.contains("android_asset/")) {
                    injectAutoBotEngine(view);
                }
            }
        });

        wv.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (fileUploadCallback != null) {
                    fileUploadCallback.onReceiveValue(null);
                }
                // Automatic hands-free file supply when Flow AI or ChatGPT bot clicks 'Upload' for a scene image!
                if (pendingAutoUploadSceneNo > 0) {
                    int sceneToUpload = pendingAutoUploadSceneNo;
                    pendingAutoUploadSceneNo = 0;
                    File readySceneFile = ensureSceneImageInInternalFile(sceneToUpload);
                    if (readySceneFile != null && readySceneFile.exists()) {
                        filePathCallback.onReceiveValue(new Uri[]{Uri.fromFile(readySceneFile)});
                        return true;
                    }
                }
                fileUploadCallback = filePathCallback;
                try {
                    Intent intent = fileChooserParams.createIntent();
                    startActivityForResult(intent, FILE_CHOOSER_RESULT_CODE);
                } catch (Exception e) {
                    fileUploadCallback = null;
                    return false;
                }
                return true;
            }
        });

        if (!isHomeWebView) {
            wv.setDownloadListener(new DownloadListener() {
                @Override
                public void onDownloadStart(final String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
                    if (activeDownloadSceneNo > 0 && url != null && url.startsWith("http")) {
                        final int sceneSnap = activeDownloadSceneNo;
                        bgExecutor.execute(() -> downloadImageWithCookiesInternal(sceneSnap, url, CHATGPT_URL));
                    }
                }
            });
        }

        return wv;
    }

    private void loadAutoBotAssetIntoRam() {
        try {
            InputStream is = getAssets().open("autobot.js");
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = is.read(buf)) != -1) {
                baos.write(buf, 0, n);
            }
            is.close();
            cachedAutoBotJs = new String(baos.toByteArray(), StandardCharsets.UTF_8);
        } catch (Exception ignored) {}
    }

    private void injectAutoBotEngine(WebView view) {
        if (cachedAutoBotJs == null || cachedAutoBotJs.isEmpty()) {
            loadAutoBotAssetIntoRam();
        }
        if (cachedAutoBotJs != null && !cachedAutoBotJs.isEmpty()) {
            view.evaluateJavascript(cachedAutoBotJs, null);
        }
    }

    private void launchNativeFolderPicker() {
        try {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                    | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
            startActivityForResult(intent, FOLDER_PICKER_RESULT_CODE);
        } catch (Exception e) {
            completeFolderSetupWithDefault();
        }
    }

    private void completeFolderSetupWithDefault() {
        File base = getAppInternalMirrorRoot();
        prefs.edit()
                .putBoolean("FOLDER_SETUP_DONE", true)
                .putString("SELECTED_FOLDER_DISPLAY", base.getAbsolutePath())
                .apply();
        ensureSubfoldersExist();
        runOnUiThread(() -> {
            topBarContainer.setVisibility(View.VISIBLE);
            switchVisibleTab("home");
            String js = "if(window.onNativeFolderSetupFinished){window.onNativeFolderSetupFinished("
                    + JSONObject.quote(base.getAbsolutePath()) + ");}";
            homeWebView.evaluateJavascript(js, null);
        });
    }

    private File getAppInternalMirrorRoot() {
        File dir = new File(getExternalFilesDir(null), "FluidStudio_Workspace");
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    private File getInternalPdfsFolder() {
        File dir = new File(getAppInternalMirrorRoot(), "pdfs");
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    private File getAccountFolderFile() {
        File accDir = new File(getAppInternalMirrorRoot(), "Account");
        if (!accDir.exists()) accDir.mkdirs();
        return accDir;
    }

    private File getOutputImagesFolderFile() {
        File imgDir = new File(getAppInternalMirrorRoot(), "output_images");
        if (!imgDir.exists()) imgDir.mkdirs();
        return imgDir;
    }

    private File getReportsFolderFile() {
        File repDir = new File(getAppInternalMirrorRoot(), "scene_account_reports");
        if (!repDir.exists()) repDir.mkdirs();
        return repDir;
    }

    private File resolveFilesystemPathFromTreeUri(Uri treeUri) {
        try {
            String docId = DocumentsContract.getTreeDocumentId(treeUri);
            if (docId != null && docId.contains(":")) {
                String[] split = docId.split(":", 2);
                String type = split[0];
                String relPath = split.length > 1 ? split[1] : "";
                if ("primary".equalsIgnoreCase(type)) {
                    File extRoot = Environment.getExternalStorageDirectory();
                    return relPath.isEmpty() ? extRoot : new File(extRoot, relPath);
                }
            }
        } catch (Exception ignored) {}
        return getAppInternalMirrorRoot();
    }

    private File getUserChosenFsFolderOrNull() {
        String customPath = prefs.getString("SELECTED_FOLDER_FS_PATH", "");
        if (customPath != null && !customPath.isEmpty()) {
            return new File(customPath);
        }
        return null;
    }

    private Uri getSavedTreeUri() {
        String s = prefs.getString("SELECTED_TREE_URI", "");
        if (s == null || s.isEmpty()) return null;
        try {
            return Uri.parse(s);
        } catch (Exception e) {
            return null;
        }
    }

    private Uri findOrCreateSafSubfolder(Uri treeUri, String parentDocId, String folderName) {
        try {
            ContentResolver cr = getContentResolver();
            Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentDocId);
            Cursor c = cr.query(childrenUri, new String[]{
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_MIME_TYPE
            }, null, null, null);
            if (c != null) {
                while (c.moveToNext()) {
                    String docId = c.getString(0);
                    String name = c.getString(1);
                    String mime = c.getString(2);
                    if (folderName.equalsIgnoreCase(name)
                            && DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) {
                        c.close();
                        return DocumentsContract.buildDocumentUriUsingTree(treeUri, docId);
                    }
                }
                c.close();
            }
            Uri parentDocUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, parentDocId);
            return DocumentsContract.createDocument(
                    cr, parentDocUri, DocumentsContract.Document.MIME_TYPE_DIR, folderName);
        } catch (Exception e) {
            return null;
        }
    }

    private void writeBytesToSafSubfolder(String subfolderName, String fileName, String mimeType, byte[] data) {
        Uri treeUri = getSavedTreeUri();
        if (treeUri == null) return;
        try {
            ContentResolver cr = getContentResolver();
            String rootDocId = DocumentsContract.getTreeDocumentId(treeUri);
            Uri targetFolderUri = (subfolderName == null || subfolderName.isEmpty())
                    ? DocumentsContract.buildDocumentUriUsingTree(treeUri, rootDocId)
                    : findOrCreateSafSubfolder(treeUri, rootDocId, subfolderName);
            if (targetFolderUri == null) return;

            String folderDocId = DocumentsContract.getDocumentId(targetFolderUri);
            Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, folderDocId);
            Cursor c = cr.query(childrenUri, new String[]{
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME
            }, null, null, null);
            Uri existingFileUri = null;
            if (c != null) {
                while (c.moveToNext()) {
                    if (fileName.equalsIgnoreCase(c.getString(1))) {
                        existingFileUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, c.getString(0));
                        break;
                    }
                }
                c.close();
            }
            Uri fileUri = existingFileUri != null
                    ? existingFileUri
                    : DocumentsContract.createDocument(cr, targetFolderUri, mimeType, fileName);
            if (fileUri != null) {
                OutputStream os = cr.openOutputStream(fileUri, "wt");
                if (os != null) {
                    os.write(data);
                    os.flush();
                    os.close();
                }
            }
        } catch (Exception ignored) {}
    }

    private byte[] readBytesFromSafSubfolder(String subfolderName, String fileName) {
        Uri treeUri = getSavedTreeUri();
        if (treeUri == null) return null;
        try {
            ContentResolver cr = getContentResolver();
            String rootDocId = DocumentsContract.getTreeDocumentId(treeUri);
            Uri folderUri = (subfolderName == null || subfolderName.isEmpty())
                    ? DocumentsContract.buildDocumentUriUsingTree(treeUri, rootDocId)
                    : findOrCreateSafSubfolder(treeUri, rootDocId, subfolderName);
            if (folderUri == null) return null;
            String folderDocId = DocumentsContract.getDocumentId(folderUri);
            Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, folderDocId);
            Cursor c = cr.query(childrenUri, new String[]{
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME
            }, null, null, null);
            if (c != null) {
                while (c.moveToNext()) {
                    String docId = c.getString(0);
                    String name = c.getString(1);
                    if (fileName.equalsIgnoreCase(name)) {
                        c.close();
                        Uri docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, docId);
                        InputStream is = cr.openInputStream(docUri);
                        if (is != null) {
                            ByteArrayOutputStream baos = new ByteArrayOutputStream();
                            byte[] buf = new byte[8192];
                            int n;
                            while ((n = is.read(buf)) != -1) baos.write(buf, 0, n);
                            is.close();
                            return baos.toByteArray();
                        }
                        return null;
                    }
                }
                c.close();
            }
        } catch (Exception ignored) {}
        return null;
    }

    private void deleteSafAccountFiles(String prefix) {
        Uri treeUri = getSavedTreeUri();
        if (treeUri == null) return;
        try {
            ContentResolver cr = getContentResolver();
            String rootDocId = DocumentsContract.getTreeDocumentId(treeUri);
            Uri accFolderUri = findOrCreateSafSubfolder(treeUri, rootDocId, "Account");
            if (accFolderUri == null) return;
            String accDocId = DocumentsContract.getDocumentId(accFolderUri);
            Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, accDocId);
            Cursor c = cr.query(childrenUri, new String[]{
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME
            }, null, null, null);
            if (c != null) {
                while (c.moveToNext()) {
                    String docId = c.getString(0);
                    String name = c.getString(1);
                    if (name != null && name.startsWith(prefix)) {
                        try {
                            Uri fUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, docId);
                            DocumentsContract.deleteDocument(cr, fUri);
                        } catch (Exception ignored) {}
                    }
                }
                c.close();
            }
        } catch (Exception ignored) {}
    }

    private void ensureSubfoldersExist() {
        getAccountFolderFile();
        getOutputImagesFolderFile();
        getInternalPdfsFolder();
        getReportsFolderFile();
        Uri treeUri = getSavedTreeUri();
        if (treeUri != null) {
            bgExecutor.execute(() -> {
                try {
                    String rootDocId = DocumentsContract.getTreeDocumentId(treeUri);
                    findOrCreateSafSubfolder(treeUri, rootDocId, "Account");
                    findOrCreateSafSubfolder(treeUri, rootDocId, "output_images");
                    findOrCreateSafSubfolder(treeUri, rootDocId, "scene_account_reports");
                } catch (Exception ignored) {}
            });
        }
    }

    private boolean canActuallyOpenFile(File f) {
        if (f == null || !f.exists() || !f.isFile()) return false;
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(f);
            fis.close();
            return true;
        } catch (Exception e) {
            if (fis != null) {
                try { fis.close(); } catch (Exception ignored) {}
            }
            return false;
        }
    }

    private File ensureSceneImageInInternalFile(int sceneNo) {
        String[] candidates = new String[]{
                String.format(Locale.US, "Scene_%02d.png", sceneNo),
                String.format(Locale.US, "scene_%02d.png", sceneNo),
                "Scene_" + sceneNo + ".png",
                "scene_" + sceneNo + ".png",
                String.format(Locale.US, "Scene_%02d.jpg", sceneNo)
        };
        for (String name : candidates) {
            File f = new File(getOutputImagesFolderFile(), name);
            if (f.exists() && f.length() > 5000) return f;
        }
        for (String name : candidates) {
            byte[] safData = readBytesFromSafSubfolder("output_images", name);
            if (safData != null && safData.length > 5000) {
                File outFile = new File(getOutputImagesFolderFile(), String.format(Locale.US, "Scene_%02d.png", sceneNo));
                try {
                    FileOutputStream fos = new FileOutputStream(outFile);
                    fos.write(safData);
                    fos.flush();
                    fos.close();
                    return outFile;
                } catch (Exception ignored) {}
            }
        }
        return null;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER_RESULT_CODE) {
            if (fileUploadCallback == null) return;
            Uri[] results = null;
            if (resultCode == Activity.RESULT_OK && data != null && data.getDataString() != null) {
                results = new Uri[]{Uri.parse(data.getDataString())};
            }
            fileUploadCallback.onReceiveValue(results);
            fileUploadCallback = null;
            return;
        }

        if (requestCode == FOLDER_PICKER_RESULT_CODE) {
            if (resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
                Uri treeUri = data.getData();
                try {
                    getContentResolver().takePersistableUriPermission(
                            treeUri,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    );
                } catch (Exception ignored) {}

                File resolvedFile = resolveFilesystemPathFromTreeUri(treeUri);
                String displayPath = resolvedFile.getAbsolutePath();
                prefs.edit()
                        .putBoolean("FOLDER_SETUP_DONE", true)
                        .putString("SELECTED_TREE_URI", treeUri.toString())
                        .putString("SELECTED_FOLDER_FS_PATH", displayPath)
                        .putString("SELECTED_FOLDER_DISPLAY", displayPath)
                        .apply();

                ensureSubfoldersExist();
                topBarContainer.setVisibility(View.VISIBLE);
                switchVisibleTab("home");
                String js = "if(window.onNativeFolderSetupFinished){window.onNativeFolderSetupFinished("
                        + JSONObject.quote(displayPath) + ");}";
                homeWebView.evaluateJavascript(js, null);
            } else {
                completeFolderSetupWithDefault();
            }
            return;
        }

        if (requestCode == NEW_PDF_PICKER_RESULT_CODE) {
            if (resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
                final Uri pdfUri = data.getData();
                bgExecutor.execute(() -> {
                    try {
                        ContentResolver cr = getContentResolver();
                        String fileName = "Script_" + System.currentTimeMillis() + ".pdf";
                        Cursor cursor = cr.query(pdfUri, null, null, null, null);
                        if (cursor != null) {
                            int nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                            if (nameIdx != -1 && cursor.moveToFirst()) {
                                String disp = cursor.getString(nameIdx);
                                if (disp != null && !disp.isEmpty()) fileName = disp;
                            }
                            cursor.close();
                        }
                        if (!fileName.toLowerCase(Locale.ROOT).endsWith(".pdf")) {
                            fileName = fileName + ".pdf";
                        }

                        InputStream is = cr.openInputStream(pdfUri);
                        if (is == null) return;
                        ByteArrayOutputStream baos = new ByteArrayOutputStream();
                        byte[] buf = new byte[8192];
                        int n;
                        while ((n = is.read(buf)) != -1) {
                            baos.write(buf, 0, n);
                        }
                        is.close();
                        byte[] pdfBytes = baos.toByteArray();

                        File internalPdf = new File(getInternalPdfsFolder(), fileName);
                        try {
                            FileOutputStream fos = new FileOutputStream(internalPdf);
                            fos.write(pdfBytes);
                            fos.flush();
                            fos.close();
                        } catch (Exception ignored) {}

                        writeBytesToSafSubfolder("", fileName, "application/pdf", pdfBytes);

                        final String finalName = fileName;
                        final String b64Data = Base64.encodeToString(pdfBytes, Base64.NO_WRAP);
                        runOnUiThread(() -> {
                            switchVisibleTab("home");
                            String js = "if(window.onNativeNewPdfPicked){window.onNativeNewPdfPicked("
                                    + JSONObject.quote(finalName) + ","
                                    + JSONObject.quote(b64Data) + ");}";
                            homeWebView.evaluateJavascript(js, null);
                        });
                    } catch (Exception e) {
                        runOnUiThread(() -> Toast.makeText(MainActivity.this, "PDF load error: " + e.getMessage(), Toast.LENGTH_LONG).show());
                    }
                });
            }
            return;
        }

        super.onActivityResult(requestCode, resultCode, data);
    }

    // =========================================================================
    // 1-TAP GOOGLE ACCOUNT CHOOSER + MULTI-ACCOUNT SESSION VAULT
    // =========================================================================
    private String getBotPrefix(int botType) {
        return (botType == 2) ? "Flow_Account_" : "Account_";
    }

    private String[] getBotAuthDomains(int botType) {
        return (botType == 2) ? FLOW_AUTH_DOMAINS : CHATGPT_AUTH_DOMAINS;
    }

    // Clears ONLY the target site's session cookies while KEEPING `accounts.google.com` multi-account chooser intact!
    // This makes "Continue with Google" show all Gmail accounts for 1-Tap login just like in the user's video!
    private void clearOnlyBotSiteCookiesKeepGoogleChooser(int botType) {
        CookieManager cm = CookieManager.getInstance();
        String[] siteDomains = (botType == 2) ? FLOW_ONLY_DOMAINS : CHATGPT_ONLY_DOMAINS;
        for (String dUrl : siteDomains) {
            String raw = cm.getCookie(dUrl);
            if (raw == null || raw.isEmpty()) continue;
            String[] pairs = raw.split(";");
            for (String p : pairs) {
                String trimmed = p.trim();
                int eq = trimmed.indexOf('=');
                String name = eq > 0 ? trimmed.substring(0, eq).trim() : trimmed;
                if (name.isEmpty()) continue;
                cm.setCookie(dUrl, name + "=; Max-Age=0; Path=/; Secure");
                cm.setCookie(dUrl, name + "=; Max-Age=0; Path=/");
            }
        }
        cm.flush();
    }

    private int getSavedAccountCountInternal(int botType) {
        String prefix = getBotPrefix(botType);
        Set<Integer> foundNums = new LinkedHashSet<>();

        File accDir = getAccountFolderFile();
        File[] files = accDir.listFiles();
        if (files != null) {
            for (File f : files) {
                String name = f.getName();
                if (name.startsWith(prefix) && name.endsWith(".json") && f.length() > 5) {
                    try {
                        String numPart = name.substring(prefix.length(), name.length() - 5);
                        foundNums.add(Integer.parseInt(numPart));
                    } catch (Exception ignored) {}
                }
            }
        }

        Uri treeUri = getSavedTreeUri();
        if (treeUri != null) {
            try {
                ContentResolver cr = getContentResolver();
                String rootDocId = DocumentsContract.getTreeDocumentId(treeUri);
                Uri accFolderUri = findOrCreateSafSubfolder(treeUri, rootDocId, "Account");
                if (accFolderUri != null) {
                    String accDocId = DocumentsContract.getDocumentId(accFolderUri);
                    Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, accDocId);
                    Cursor c = cr.query(childrenUri, new String[]{DocumentsContract.Document.COLUMN_DISPLAY_NAME}, null, null, null);
                    if (c != null) {
                        while (c.moveToNext()) {
                            String name = c.getString(0);
                            if (name != null && name.startsWith(prefix) && name.endsWith(".json")) {
                                try {
                                    String numPart = name.substring(prefix.length(), name.length() - 5);
                                    foundNums.add(Integer.parseInt(numPart));
                                } catch (Exception ignored) {}
                            }
                        }
                        c.close();
                    }
                }
            } catch (Exception ignored) {}
        }

        int prefCount = prefs.getInt("SAVED_ACC_COUNT_BOT_" + botType, 0);
        return Math.max(foundNums.size(), prefCount);
    }

    private String saveAccountSessionToFolderInternal(int botType, int accNo, String optionalLocalStorageJson) {
        String prefix = getBotPrefix(botType);
        String[] domains = getBotAuthDomains(botType);
        CookieManager cm = CookieManager.getInstance();
        cm.flush();

        try {
            JSONObject domainCookiesMap = new JSONObject();
            for (String dUrl : domains) {
                String cStr = cm.getCookie(dUrl);
                if (cStr != null && !cStr.isEmpty()) {
                    domainCookiesMap.put(dUrl, cStr);
                }
            }

            JSONObject obj = new JSONObject();
            obj.put("accountName", prefix + accNo);
            obj.put("botType", botType);
            obj.put("domainCookies", domainCookiesMap);
            if (optionalLocalStorageJson != null && !optionalLocalStorageJson.isEmpty()) {
                obj.put("localStorage", optionalLocalStorageJson);
            }
            obj.put("savedAt", System.currentTimeMillis());

            String serialized = obj.toString();
            byte[] jsonBytes = serialized.getBytes(StandardCharsets.UTF_8);

            String fileName = prefix + accNo + ".json";
            File outFile = new File(getAccountFolderFile(), fileName);
            try {
                FileOutputStream fos = new FileOutputStream(outFile);
                fos.write(jsonBytes);
                fos.flush();
                fos.close();
            } catch (Exception ignored) {}

            writeBytesToSafSubfolder("Account", fileName, "application/json", jsonBytes);

            int prevCount = getSavedAccountCountInternal(botType);
            SharedPreferences.Editor ed = prefs.edit();
            ed.putString("ACC_BUNDLE_" + prefix + accNo, serialized);
            ed.putInt("SAVED_ACC_COUNT_BOT_" + botType, Math.max(prevCount, accNo));
            ed.putBoolean("LIMIT_REACHED_" + prefix + accNo, false);
            if (botType == 2) {
                currentlyLoadedFlowAcc = accNo;
                ed.putInt("LOADED_FLOW_ACC_NOW", accNo);
            } else {
                currentlyLoadedChatGptAcc = accNo;
                ed.putInt("LOADED_CHATGPT_ACC_NOW", accNo);
            }
            ed.apply();

            return "Account/" + fileName;
        } catch (Exception e) {
            return "Account/" + prefix + accNo + ".json";
        }
    }

    private JSONObject readSavedAccountJson(int botType, int accNo) {
        String prefix = getBotPrefix(botType);
        String fileName = prefix + accNo + ".json";
        File inFile = new File(getAccountFolderFile(), fileName);
        if (inFile.exists() && inFile.length() > 5) {
            try {
                FileInputStream fis = new FileInputStream(inFile);
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int n;
                while ((n = fis.read(buf)) != -1) baos.write(buf, 0, n);
                fis.close();
                return new JSONObject(new String(baos.toByteArray(), StandardCharsets.UTF_8));
            } catch (Exception ignored) {}
        }
        byte[] safBytes = readBytesFromSafSubfolder("Account", fileName);
        if (safBytes != null && safBytes.length > 5) {
            try {
                return new JSONObject(new String(safBytes, StandardCharsets.UTF_8));
            } catch (Exception ignored) {}
        }
        String fallback = prefs.getString("ACC_BUNDLE_" + prefix + accNo, "");
        if (fallback != null && !fallback.isEmpty()) {
            try {
                return new JSONObject(fallback);
            } catch (Exception ignored) {}
        }
        return null;
    }

    private void applyCookieStringToDomain(CookieManager cm, String domainUrl, String rawCookieHeader) {
        if (rawCookieHeader == null || rawCookieHeader.isEmpty()) return;
        String[] pairs = rawCookieHeader.split(";");
        for (String rawPair : pairs) {
            String pair = rawPair.trim();
            if (pair.isEmpty() || !pair.contains("=")) continue;
            cm.setCookie(domainUrl, pair + "; Path=/; Secure; SameSite=Lax");
        }
    }

    private void loadAccountCookiesIntoWebView(final int botType, final int accNo, final boolean clearSiteFirst, final Runnable onDone) {
        final JSONObject savedObj = readSavedAccountJson(botType, accNo);
        final CookieManager cm = CookieManager.getInstance();

        if (clearSiteFirst) {
            clearOnlyBotSiteCookiesKeepGoogleChooser(botType);
        }

        if (savedObj != null) {
            JSONObject domainCookies = savedObj.optJSONObject("domainCookies");
            if (domainCookies != null) {
                Iterator<String> keys = domainCookies.keys();
                while (keys.hasNext()) {
                    String dUrl = keys.next();
                    String cVal = domainCookies.optString(dUrl, "");
                    applyCookieStringToDomain(cm, dUrl, cVal);
                }
            } else {
                String legacyCookies = savedObj.optString("cookies", "");
                String primaryDomain = (botType == 2) ? "https://labs.google/" : "https://chatgpt.com/";
                applyCookieStringToDomain(cm, primaryDomain, legacyCookies);
            }
        }
        cm.flush();
        if (botType == 2) {
            currentlyLoadedFlowAcc = accNo;
            prefs.edit().putInt("LOADED_FLOW_ACC_NOW", accNo).apply();
        } else {
            currentlyLoadedChatGptAcc = accNo;
            prefs.edit().putInt("LOADED_CHATGPT_ACC_NOW", accNo).apply();
        }
        if (onDone != null) onDone.run();
    }

    private void deleteAllSavedAccountsInternal(int botType) {
        String prefix = getBotPrefix(botType);
        File accDir = getAccountFolderFile();
        File[] files = accDir.listFiles();
        if (files != null) {
            for (File f : files) {
                if (f.getName().startsWith(prefix)) {
                    f.delete();
                }
            }
        }
        bgExecutor.execute(() -> deleteSafAccountFiles(prefix));

        SharedPreferences.Editor ed = prefs.edit();
        for (int i = 1; i <= 30; i++) {
            ed.remove("ACC_BUNDLE_" + prefix + i);
            ed.remove("ACC_COOKIES_" + prefix + i);
            ed.remove("LIMIT_REACHED_" + prefix + i);
        }
        ed.putInt("SAVED_ACC_COUNT_BOT_" + botType, 0);
        if (botType == 2) {
            currentFlowAccountIndex = 1;
            currentlyLoadedFlowAcc = 0;
            ed.putInt("ACTIVE_FLOW_ACC_IDX", 1);
            ed.putInt("LOADED_FLOW_ACC_NOW", 0);
        } else {
            currentChatGptAccountIndex = 1;
            currentlyLoadedChatGptAcc = 0;
            ed.putInt("ACTIVE_CHATGPT_ACC_IDX", 1);
            ed.putInt("LOADED_CHATGPT_ACC_NOW", 0);
        }
        ed.apply();

        // Only clear the bot site cookies so Google 1-Tap chooser accounts stay ready!
        clearOnlyBotSiteCookiesKeepGoogleChooser(botType);
    }

    private String saveImageBytesToOutputFolder(int sceneNo, byte[] imgBytes) {
        if (imgBytes == null || imgBytes.length < 5000) {
            return "ERROR: Image too small";
        }
        String fileName = String.format(Locale.US, "Scene_%02d.png", sceneNo);
        File outFile = new File(getOutputImagesFolderFile(), fileName);
        try {
            FileOutputStream fos = new FileOutputStream(outFile);
            fos.write(imgBytes);
            fos.flush();
            fos.close();
        } catch (Exception ignored) {}
        writeBytesToSafSubfolder("output_images", fileName, "image/png", imgBytes);
        return outFile.getAbsolutePath();
    }

    private String downloadImageWithCookiesInternal(int sceneNo, String imgUrl, String pageUrl) {
        HttpURLConnection conn = null;
        try {
            String currentUrl = imgUrl;
            CookieManager cm = CookieManager.getInstance();

            for (int hop = 0; hop < 6; hop++) {
                URL url = new URL(currentUrl);
                conn = (HttpURLConnection) url.openConnection();
                conn.setInstanceFollowRedirects(false);
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(25000);
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Accept", "image/avif,image/webp,image/apng,image/*,*/*;q=0.8");
                conn.setRequestProperty("User-Agent", cleanChromeUa != null && !cleanChromeUa.isEmpty() ? cleanChromeUa : "Mozilla/5.0 (Android 14)");
                if (pageUrl != null && !pageUrl.isEmpty()) {
                    conn.setRequestProperty("Referer", pageUrl);
                }

                String c1 = cm.getCookie(currentUrl);
                String c2 = (pageUrl != null && !pageUrl.isEmpty()) ? cm.getCookie(pageUrl) : null;
                String cookies = (c1 != null && !c1.isEmpty()) ? c1 : (c2 != null ? c2 : "");
                if (!cookies.isEmpty()) {
                    conn.setRequestProperty("Cookie", cookies);
                }

                int status = conn.getResponseCode();
                if (status == HttpURLConnection.HTTP_MOVED_TEMP
                        || status == HttpURLConnection.HTTP_MOVED_PERM
                        || status == HttpURLConnection.HTTP_SEE_OTHER
                        || status == 307
                        || status == 308) {
                    String loc = conn.getHeaderField("Location");
                    conn.disconnect();
                    if (loc == null || loc.isEmpty()) break;
                    if (loc.startsWith("/")) {
                        loc = url.getProtocol() + "://" + url.getHost() + loc;
                    }
                    currentUrl = loc;
                    continue;
                }

                if (status >= 200 && status < 300) {
                    InputStream is = conn.getInputStream();
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = is.read(buf)) != -1) baos.write(buf, 0, n);
                    is.close();
                    conn.disconnect();
                    return saveImageBytesToOutputFolder(sceneNo, baos.toByteArray());
                } else {
                    conn.disconnect();
                    return "ERROR: HTTP " + status;
                }
            }
            return "ERROR: Too many redirects";
        } catch (Exception e) {
            if (conn != null) {
                try { conn.disconnect(); } catch (Exception ignored) {}
            }
            return "ERROR: " + e.getMessage();
        }
    }

    public class AndroidBotBridge {

        @JavascriptInterface
        public void notifyTerminalScreenOpened() {
            runOnUiThread(() -> topBarContainer.setVisibility(View.VISIBLE));
        }

        @JavascriptInterface
        public void switchTabFromWeb(final String tabName) {
            runOnUiThread(() -> switchVisibleTab(tabName != null ? tabName : "home"));
        }

        @JavascriptInterface
        public void warmUpBotWebView(final int botType) {
            runOnUiThread(() -> {
                if (botType == 2) ensureFlowLoaded();
                else ensureChatGptLoaded();
            });
        }

        @JavascriptInterface
        public boolean isFolderAlreadyConfigured() {
            return prefs.getBoolean("FOLDER_SETUP_DONE", false);
        }

        @JavascriptInterface
        public String getSelectedFolderDisplay() {
            return prefs.getString("SELECTED_FOLDER_DISPLAY", getAppInternalMirrorRoot().getAbsolutePath());
        }

        @JavascriptInterface
        public void requestInitialFolderSetup() {
            runOnUiThread(() -> launchNativeFolderPicker());
        }

        @JavascriptInterface
        public void openFolderPickerFromHome() {
            runOnUiThread(() -> launchNativeFolderPicker());
        }

        @JavascriptInterface
        public int getSavedAccountCount(final int botType) {
            return getSavedAccountCountInternal(botType);
        }

        @JavascriptInterface
        public void deleteAllSavedAccounts(final int botType) {
            runOnUiThread(() -> deleteAllSavedAccountsInternal(botType));
        }

        // Opens Google's Multi-Account Session Manager so user can sign into all their Gmail IDs once,
        // enabling the 1-Tap Google Account Chooser list shown in the user's video!
        @JavascriptInterface
        public void openGoogleMultiAccountAdder(final int botType) {
            runOnUiThread(() -> {
                WebView targetWv = (botType == 2) ? flowWebView : chatgptWebView;
                if (botType == 2) flowInitialLoaded = true;
                else chatgptInitialLoaded = true;
                targetWv.loadUrl("https://accounts.google.com/AddSession?hl=en&continue="
                        + (botType == 2 ? "https://labs.google/fx/tools/flow" : "https://chatgpt.com/"));
                switchVisibleTab(botType == 2 ? "flow" : "chatgpt");
            });
        }

        @JavascriptInterface
        public void prepareAccountSetupInBrowser(final int botType, final int accNo) {
            runOnUiThread(() -> {
                int totalSaved = getSavedAccountCountInternal(botType);
                if (accNo > 1 || totalSaved > 0) {
                    // Preserve `accounts.google.com` cookies so the 1-Tap Google Account Chooser shows all Gmail IDs!
                    clearOnlyBotSiteCookiesKeepGoogleChooser(botType);
                    if (botType == 2) {
                        flowInitialLoaded = true;
                        flowWebView.loadUrl(FLOW_URL);
                        switchVisibleTab("flow");
                    } else {
                        chatgptInitialLoaded = true;
                        chatgptWebView.loadUrl(CHATGPT_URL);
                        switchVisibleTab("chatgpt");
                    }
                } else {
                    if (botType == 2) {
                        ensureFlowLoaded();
                        switchVisibleTab("flow");
                    } else {
                        ensureChatGptLoaded();
                        switchVisibleTab("chatgpt");
                    }
                }
            });
        }

        @JavascriptInterface
        public String saveCurrentAccountToFolder(final int botType, final int accNo) {
            return saveAccountSessionToFolderInternal(botType, accNo, null);
        }

        @JavascriptInterface
        public void autoSyncActiveAccountCookies(final int botType, final String localStorageJson) {
            int activeAcc = (botType == 2) ? currentFlowAccountIndex : currentChatGptAccountIndex;
            if (activeAcc < 1) activeAcc = 1;
            final int targetAcc = activeAcc;
            bgExecutor.execute(() -> saveAccountSessionToFolderInternal(botType, targetAcc, localStorageJson));
        }

        @JavascriptInterface
        public void activateFirstSavedAccountAfterSetup(final int botType) {
            runOnUiThread(() -> {
                int total = getSavedAccountCountInternal(botType);
                if (total <= 1) {
                    if (botType == 2) {
                        currentFlowAccountIndex = 1;
                        currentlyLoadedFlowAcc = 1;
                    } else {
                        currentChatGptAccountIndex = 1;
                        currentlyLoadedChatGptAcc = 1;
                    }
                    return;
                }
                if (botType == 2) {
                    currentFlowAccountIndex = 1;
                    loadAccountCookiesIntoWebView(2, 1, true, () -> flowWebView.loadUrl(FLOW_URL));
                } else {
                    currentChatGptAccountIndex = 1;
                    loadAccountCookiesIntoWebView(1, 1, true, () -> chatgptWebView.loadUrl(CHATGPT_URL));
                }
            });
        }

        @JavascriptInterface
        public void resetAllAccountLimits(final int botType) {
            String prefix = getBotPrefix(botType);
            int total = getSavedAccountCountInternal(botType);
            SharedPreferences.Editor ed = prefs.edit();
            for (int i = 1; i <= Math.max(total, 20); i++) {
                ed.putBoolean("LIMIT_REACHED_" + prefix + i, false);
            }
            if (botType == 2) {
                currentFlowAccountIndex = 1;
                ed.putInt("ACTIVE_FLOW_ACC_IDX", 1);
                ed.remove("FLOW_DAILY_EXHAUSTED_JSON");
            } else {
                currentChatGptAccountIndex = 1;
                ed.putInt("ACTIVE_CHATGPT_ACC_IDX", 1);
            }
            ed.apply();
        }

        @JavascriptInterface
        public String getActiveAccountLabel(final int botType) {
            String prefix = getBotPrefix(botType);
            int idx = (botType == 2) ? currentFlowAccountIndex : currentChatGptAccountIndex;
            return prefix + Math.max(1, idx);
        }

        @JavascriptInterface
        public String listFolderPdfsJson() {
            Set<String> pdfNames = new LinkedHashSet<>();

            Uri treeUri = getSavedTreeUri();
            if (treeUri != null) {
                try {
                    ContentResolver cr = getContentResolver();
                    String rootDocId = DocumentsContract.getTreeDocumentId(treeUri);
                    Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, rootDocId);
                    Cursor c = cr.query(childrenUri, new String[]{DocumentsContract.Document.COLUMN_DISPLAY_NAME}, null, null, null);
                    if (c != null) {
                        while (c.moveToNext()) {
                            String name = c.getString(0);
                            if (name != null && name.toLowerCase(Locale.ROOT).endsWith(".pdf")) {
                                pdfNames.add(name);
                            }
                        }
                        c.close();
                    }
                } catch (Exception ignored) {}
            }

            try {
                File[] internalFiles = getInternalPdfsFolder().listFiles();
                if (internalFiles != null) {
                    for (File f : internalFiles) {
                        if (f.isFile() && f.getName().toLowerCase(Locale.ROOT).endsWith(".pdf")) {
                            pdfNames.add(f.getName());
                        }
                    }
                }
            } catch (Exception ignored) {}

            try {
                File userFs = getUserChosenFsFolderOrNull();
                if (userFs != null && userFs.exists()) {
                    File[] files = userFs.listFiles();
                    if (files != null) {
                        for (File f : files) {
                            if (f.getName().toLowerCase(Locale.ROOT).endsWith(".pdf") && canActuallyOpenFile(f)) {
                                pdfNames.add(f.getName());
                            }
                        }
                    }
                }
            } catch (Exception ignored) {}

            List<String> sorted = new ArrayList<>(pdfNames);
            Collections.sort(sorted, String.CASE_INSENSITIVE_ORDER);
            JSONArray arr = new JSONArray();
            for (String s : sorted) arr.put(s);
            return arr.toString();
        }

        @JavascriptInterface
        public String readFolderPdfBase64(final String pdfFileName) {
            byte[] safBytes = readBytesFromSafSubfolder("", pdfFileName);
            if (safBytes != null && safBytes.length > 10) {
                return Base64.encodeToString(safBytes, Base64.NO_WRAP);
            }

            try {
                File intFile = new File(getInternalPdfsFolder(), pdfFileName);
                if (intFile.exists() && intFile.isFile()) {
                    FileInputStream fis = new FileInputStream(intFile);
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = fis.read(buf)) != -1) baos.write(buf, 0, n);
                    fis.close();
                    return Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP);
                }
            } catch (Exception ignored) {}

            try {
                File userFs = getUserChosenFsFolderOrNull();
                if (userFs != null) {
                    File f = new File(userFs, pdfFileName);
                    if (canActuallyOpenFile(f)) {
                        FileInputStream fis = new FileInputStream(f);
                        ByteArrayOutputStream baos = new ByteArrayOutputStream();
                        byte[] buf = new byte[8192];
                        int n;
                        while ((n = fis.read(buf)) != -1) baos.write(buf, 0, n);
                        fis.close();
                        return Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP);
                    }
                }
            } catch (Exception ignored) {}

            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/pdf");
                    startActivityForResult(intent, NEW_PDF_PICKER_RESULT_CODE);
                } catch (Exception ignored) {}
            });
            return "OPENED_PICKER";
        }

        @JavascriptInterface
        public void pickNewPdfFromFileManager() {
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/pdf");
                    startActivityForResult(intent, NEW_PDF_PICKER_RESULT_CODE);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "File manager error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void saveUploadedPdfToFolder(final String fileName, final String cleanBase64) {
            try {
                byte[] bytes = Base64.decode(cleanBase64, Base64.DEFAULT);
                File out = new File(getInternalPdfsFolder(), fileName);
                try {
                    FileOutputStream fos = new FileOutputStream(out);
                    fos.write(bytes);
                    fos.flush();
                    fos.close();
                } catch (Exception ignored) {}
                writeBytesToSafSubfolder("", fileName, "application/pdf", bytes);
            } catch (Exception ignored) {}
        }

        // Returns JSON array of scene numbers that have existing images in `output_images/`
        @JavascriptInterface
        public String getAvailableSceneImagesJson() {
            Set<Integer> sceneNums = new LinkedHashSet<>();
            Pattern pat = Pattern.compile("scene_?(\\d+)\\.(?:png|jpg|jpeg|webp)", Pattern.CASE_INSENSITIVE);

            try {
                File[] files = getOutputImagesFolderFile().listFiles();
                if (files != null) {
                    for (File f : files) {
                        if (f.isFile() && f.length() > 5000) {
                            Matcher m = pat.matcher(f.getName());
                            if (m.matches()) {
                                sceneNums.add(Integer.parseInt(m.group(1)));
                            }
                        }
                    }
                }
            } catch (Exception ignored) {}

            Uri treeUri = getSavedTreeUri();
            if (treeUri != null) {
                try {
                    ContentResolver cr = getContentResolver();
                    String rootDocId = DocumentsContract.getTreeDocumentId(treeUri);
                    Uri imgFolderUri = findOrCreateSafSubfolder(treeUri, rootDocId, "output_images");
                    if (imgFolderUri != null) {
                        String imgDocId = DocumentsContract.getDocumentId(imgFolderUri);
                        Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, imgDocId);
                        Cursor c = cr.query(childrenUri, new String[]{DocumentsContract.Document.COLUMN_DISPLAY_NAME}, null, null, null);
                        if (c != null) {
                            while (c.moveToNext()) {
                                String name = c.getString(0);
                                if (name != null) {
                                    Matcher m = pat.matcher(name);
                                    if (m.matches()) {
                                        sceneNums.add(Integer.parseInt(m.group(1)));
                                    }
                                }
                            }
                            c.close();
                        }
                    }
                } catch (Exception ignored) {}
            }

            List<Integer> sorted = new ArrayList<>(sceneNums);
            Collections.sort(sorted);
            JSONArray arr = new JSONArray();
            for (int n : sorted) arr.put(n);
            return arr.toString();
        }

        @JavascriptInterface
        public void setPendingAutoUploadSceneImage(final int sceneNo) {
            pendingAutoUploadSceneNo = sceneNo;
        }

        @JavascriptInterface
        public String getSceneImageBase64(final int sceneNo) {
            File f = ensureSceneImageInInternalFile(sceneNo);
            if (f != null && f.exists()) {
                try {
                    FileInputStream fis = new FileInputStream(f);
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = fis.read(buf)) != -1) baos.write(buf, 0, n);
                    fis.close();
                    return "data:image/png;base64," + Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP);
                } catch (Exception ignored) {}
            }
            return "";
        }

        @JavascriptInterface
        public void saveFlowSceneAccountReport(final String pdfFileName, final String reportText) {
            bgExecutor.execute(() -> {
                try {
                    String stem = (pdfFileName != null && !pdfFileName.isEmpty())
                            ? pdfFileName.replaceAll("\\.[^.]+$", "")
                            : "Flow_Scenes";
                    String repName = stem + "_Scene_Account_Report.txt";
                    byte[] data = (reportText != null ? reportText : "").getBytes(StandardCharsets.UTF_8);

                    File out = new File(getReportsFolderFile(), repName);
                    try {
                        FileOutputStream fos = new FileOutputStream(out);
                        fos.write(data);
                        fos.flush();
                        fos.close();
                    } catch (Exception ignored) {}

                    writeBytesToSafSubfolder("scene_account_reports", repName, "text/plain", data);
                    writeBytesToSafSubfolder("scene_account_reports", "Scene_Account_Status_Report.txt", "text/plain", data);
                } catch (Exception ignored) {}
            });
        }

        // =====================================================================
        // STAR WARS GAME PROGRESS PERSISTENCE IN CHOSEN FOLDER
        // =====================================================================
        @JavascriptInterface
        public void saveGameProgressToFolder(final String jsonStr) {
            if (jsonStr == null) return;
            prefs.edit().putString("STAR_WARS_GAME_PROGRESS_JSON", jsonStr).apply();
            bgExecutor.execute(() -> {
                try {
                    byte[] bytes = jsonStr.getBytes(StandardCharsets.UTF_8);
                    File f = new File(getAppInternalMirrorRoot(), "star_wars_progress.json");
                    FileOutputStream fos = new FileOutputStream(f);
                    fos.write(bytes);
                    fos.flush();
                    fos.close();
                    writeBytesToSafSubfolder("", "star_wars_progress.json", "application/json", bytes);
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public String loadGameProgressFromFolder() {
            byte[] safData = readBytesFromSafSubfolder("", "star_wars_progress.json");
            if (safData != null && safData.length > 2) {
                return new String(safData, StandardCharsets.UTF_8);
            }
            try {
                File f = new File(getAppInternalMirrorRoot(), "star_wars_progress.json");
                if (f.exists() && f.length() > 2) {
                    FileInputStream fis = new FileInputStream(f);
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    byte[] buf = new byte[4096];
                    int n;
                    while ((n = fis.read(buf)) != -1) baos.write(buf, 0, n);
                    fis.close();
                    return new String(baos.toByteArray(), StandardCharsets.UTF_8);
                }
            } catch (Exception ignored) {}
            return prefs.getString("STAR_WARS_GAME_PROGRESS_JSON", "");
        }

        @JavascriptInterface
        public void startBotAutomationWithQueue(final String payloadJson) {
            try {
                JSONObject obj = new JSONObject(payloadJson);
                obj.put("active", true);
                final int botType = obj.optInt("botType", 1);
                prefs.edit().putString("ACTIVE_AUTOMATION_QUEUE_JSON", obj.toString()).apply();

                runOnUiThread(() -> {
                    int totalSaved = getSavedAccountCountInternal(botType);
                    int startIdx = (botType == 2) ? currentFlowAccountIndex : currentChatGptAccountIndex;
                    if (startIdx < 1 || (totalSaved > 0 && startIdx > totalSaved)) {
                        startIdx = 1;
                    }
                    final int chosenAcc = startIdx;
                    final int loadedNow = (botType == 2) ? currentlyLoadedFlowAcc : currentlyLoadedChatGptAcc;
                    final WebView targetWv = (botType == 2) ? flowWebView : chatgptWebView;

                    if (botType == 2) ensureFlowLoaded();
                    else ensureChatGptLoaded();

                    String curUrl = targetWv.getUrl();
                    boolean alreadyOnTargetSite = curUrl != null && (botType == 2
                            ? (curUrl.contains("labs.google") || curUrl.contains("flow.google"))
                            : curUrl.contains("chatgpt.com"));

                    if (totalSaved > 1 && loadedNow != chosenAcc) {
                        loadAccountCookiesIntoWebView(botType, chosenAcc, true, () -> {
                            targetWv.loadUrl(botType == 2 ? FLOW_URL : CHATGPT_URL);
                        });
                        return;
                    }

                    if (!alreadyOnTargetSite) {
                        loadAccountCookiesIntoWebView(botType, chosenAcc, false, () -> {
                            targetWv.loadUrl(botType == 2 ? FLOW_URL : CHATGPT_URL);
                        });
                        return;
                    }

                    injectAutoBotEngine(targetWv);
                    targetWv.evaluateJavascript("if(window.__ITK_START_QUEUE_NOW__){window.__ITK_START_QUEUE_NOW__();}", null);
                });
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public void stopAutomationFromHome() {
            prefs.edit().remove("ACTIVE_AUTOMATION_QUEUE_JSON").apply();
            runOnUiThread(() -> {
                chatgptWebView.evaluateJavascript("if(window.__ITK_STOP_QUEUE_NOW__){window.__ITK_STOP_QUEUE_NOW__();}", null);
                flowWebView.evaluateJavascript("if(window.__ITK_STOP_QUEUE_NOW__){window.__ITK_STOP_QUEUE_NOW__();}", null);
            });
        }

        @JavascriptInterface
        public boolean isAutomationCurrentlyActive() {
            String raw = prefs.getString("ACTIVE_AUTOMATION_QUEUE_JSON", "");
            return raw != null && raw.contains("\"active\":true");
        }

        @JavascriptInterface
        public String getActiveAutomationQueueJson() {
            return prefs.getString("ACTIVE_AUTOMATION_QUEUE_JSON", "");
        }

        @JavascriptInterface
        public void updateActiveAutomationQueueJson(final String updatedJson) {
            prefs.edit().putString("ACTIVE_AUTOMATION_QUEUE_JSON", updatedJson != null ? updatedJson : "").apply();
        }

        @JavascriptInterface
        public void clearActiveAutomationQueue() {
            prefs.edit().remove("ACTIVE_AUTOMATION_QUEUE_JSON").apply();
        }

        @JavascriptInterface
        public void postHomeLog(final String lineText, final String statusType) {
            runOnUiThread(() -> {
                String js = "if(window.onBotLiveStatusLine){window.onBotLiveStatusLine("
                        + JSONObject.quote(lineText != null ? lineText : "") + ","
                        + JSONObject.quote(statusType != null ? statusType : "LIVE") + ");}";
                homeWebView.evaluateJavascript(js, null);
            });
        }

        @JavascriptInterface
        public String switchToNextAccountOnLimit(final int botType) {
            String prefix = getBotPrefix(botType);
            int totalSaved = getSavedAccountCountInternal(botType);
            int currIdx = (botType == 2) ? currentFlowAccountIndex : currentChatGptAccountIndex;
            prefs.edit().putBoolean("LIMIT_REACHED_" + prefix + currIdx, true).apply();

            int nextAvailable = -1;
            for (int i = 1; i <= totalSaved; i++) {
                if (!prefs.getBoolean("LIMIT_REACHED_" + prefix + i, false)) {
                    nextAvailable = i;
                    break;
                }
            }

            if (nextAvailable == -1) {
                return "NO_MORE_ACCOUNTS";
            }

            final int targetAcc = nextAvailable;
            if (botType == 2) {
                currentFlowAccountIndex = targetAcc;
                prefs.edit().putInt("ACTIVE_FLOW_ACC_IDX", targetAcc).apply();
            } else {
                currentChatGptAccountIndex = targetAcc;
                prefs.edit().putInt("ACTIVE_CHATGPT_ACC_IDX", targetAcc).apply();
            }

            runOnUiThread(() -> {
                loadAccountCookiesIntoWebView(botType, targetAcc, true, () -> {
                    WebView wv = (botType == 2) ? flowWebView : chatgptWebView;
                    wv.loadUrl(botType == 2 ? FLOW_URL : CHATGPT_URL);
                });
            });

            return "SWITCHED:" + prefix + targetAcc;
        }

        @JavascriptInterface
        public boolean doesSceneImageExist(final int sceneNo) {
            File f = ensureSceneImageInInternalFile(sceneNo);
            return f != null && f.exists() && f.length() > 5000;
        }

        @JavascriptInterface
        public void setActiveDownloadSceneNo(final int sceneNo) {
            activeDownloadSceneNo = sceneNo;
        }

        @JavascriptInterface
        public String saveSceneImageToOutputFolder(final int sceneNo, final String base64DataUrl) {
            try {
                String cleanB64 = base64DataUrl;
                int comma = cleanB64.indexOf(',');
                if (comma != -1) cleanB64 = cleanB64.substring(comma + 1);
                byte[] bytes = Base64.decode(cleanB64, Base64.DEFAULT);
                return saveImageBytesToOutputFolder(sceneNo, bytes);
            } catch (Exception e) {
                return "ERROR: " + e.getMessage();
            }
        }

        @JavascriptInterface
        public String downloadImageUrlToOutputFolder(final int sceneNo, final String imgUrl, final String pageUrl) {
            return downloadImageWithCookiesInternal(sceneNo, imgUrl, pageUrl);
        }

        @JavascriptInterface
        public String findReferenceImageJson(final String charName) {
            try {
                String normTarget = charName.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", " ").trim();
                Uri treeUri = getSavedTreeUri();
                if (treeUri != null) {
                    try {
                        ContentResolver cr = getContentResolver();
                        String rootDocId = DocumentsContract.getTreeDocumentId(treeUri);
                        Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, rootDocId);
                        Cursor c = cr.query(childrenUri, new String[]{
                                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                                DocumentsContract.Document.COLUMN_DISPLAY_NAME
                        }, null, null, null);
                        if (c != null) {
                            while (c.moveToNext()) {
                                String docId = c.getString(0);
                                String name = c.getString(1);
                                if (name == null) continue;
                                String nLower = name.toLowerCase(Locale.ROOT);
                                if (nLower.endsWith(".png") || nLower.endsWith(".jpg") || nLower.endsWith(".jpeg") || nLower.endsWith(".webp")) {
                                    int dot = nLower.lastIndexOf('.');
                                    String stem = dot > 0 ? nLower.substring(0, dot) : nLower;
                                    String normStem = stem.replaceAll("[^a-z0-9]+", " ").trim();
                                    if (!normStem.isEmpty() && (normStem.equals(normTarget) || normStem.contains(normTarget) || normTarget.contains(normStem))) {
                                        c.close();
                                        Uri docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, docId);
                                        InputStream is = cr.openInputStream(docUri);
                                        if (is != null) {
                                            ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                            byte[] buf = new byte[4096];
                                            int r;
                                            while ((r = is.read(buf)) != -1) baos.write(buf, 0, r);
                                            is.close();
                                            JSONObject res = new JSONObject();
                                            res.put("found", true);
                                            res.put("fileName", name);
                                            res.put("base64", "data:image/png;base64," + Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP));
                                            return res.toString();
                                        }
                                        break;
                                    }
                                }
                            }
                            c.close();
                        }
                    } catch (Exception ignored) {}
                }
            } catch (Exception ignored) {}
            return "{\"found\":false}";
        }
    }

    @Override
    public void onBackPressed() {
        WebView activeWv = homeWebView;
        if ("chatgpt".equals(activeTabName)) activeWv = chatgptWebView;
        else if ("flow".equals(activeTabName)) activeWv = flowWebView;

        if (activeWv != null && activeWv != homeWebView && activeWv.canGoBack()) {
            activeWv.goBack();
            return;
        }
        if (!"home".equals(activeTabName)) {
            switchVisibleTab("home");
            return;
        }
        super.onBackPressed();
    }
}
